from django.apps import AppConfig


class UssdAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ussd_app'
